#ifndef BUILDER_H
#define BUILDER_H

#include "geometry.h"

Geometry *create_square();

#endif // BUILDER_H