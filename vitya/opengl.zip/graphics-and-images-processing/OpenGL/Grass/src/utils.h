#ifndef UTILS_H
#define UTILS_H

enum class Attributes
{
    position = 0,
    color = 1,
    normal = 2,
    texture = 7
};

#endif // UTILS_H
