#ifndef MATHGL_H
#define MATHGL_H

#include <math.h>

#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"

#endif // MATHGL_H